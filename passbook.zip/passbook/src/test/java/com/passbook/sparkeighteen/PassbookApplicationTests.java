package com.passbook.sparkeighteen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
